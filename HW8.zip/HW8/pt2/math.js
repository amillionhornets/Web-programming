
export const add = (a, b) => a + b;
export const subtract = (a, b) => a - b;
