
import { add, subtract } from './math.js';

console.log(add(10, 5));      
console.log(subtract(10, 5)); 
